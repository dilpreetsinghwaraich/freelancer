<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Request\UploadRequest;

class UploadController extends Controller
{
    
    public function uploadSubmit(UploadRequest $request){

    }
}
