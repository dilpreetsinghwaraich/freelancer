<?php $__env->startSection('content'); ?>
	<!-- Clientadmin dashboard section -->
    <div class="clientdashboardarea">
      <div class="container">
        <div class="row clienttoprow">
          <div class="col-xs-12">
            <div class='row'><a href="<?php echo e(url('jobpost')); ?>" class='btn btn-link'><b>&lt; Back to previous page</b></a></div>
          </div>
          <div class="col-md-9 col-sm-12">
            <h3 class="project-title">Job Postings</h3>
          </div>
          <div class="col-md-3 col-sm-12 text-right">
            <a href="<?php echo e(url('jobpost')); ?>" class='btn btn-primary'>Post a job</a>
          </div>
        </div>
        <div class="row">
         

          <div class="col-sm-12">
            <div class="panel panel-default panel-custom">
              <div class="panel-heading">
                <div class="form-group form-sm">
              
              <select class="form-control c-form">
                <option>All Job Postings</option>
                <option>Another action</option>
                <option>Something else here</option>
              </select>
            </div>
              </div>
              <table class="table">
                <thead>
                  <tr>
                    <th>Job</th>
                    <th>Status</th>
                    <th>Date Posted</th>
                    <th>Posted By</th>
                    <th>Hires</th>
                  </tr>
                </thead>
                <tbody>
                	<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th><a href="<?php echo e(url('jobpost')); ?>/<?php echo e($job->id); ?>/edit"> <?php echo e($job->job_title); ?></a></th>
                    <td>
                      <?php if($job->status == 1): ?>
                        <span class="label label-success">Open</span>
                      <?php else: ?>
                        <span class="label label-warning">Filled</span>
                      <?php endif; ?>
                      
                    </td>
                    <td><?php echo e(date("M d", strtotime($job->created_at))); ?> <small><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($job->created_at))->diffForHumans()); ?></small></td>
                    <td>Top notch solutionz</td>
                    <td><i class='fa fa-check-circle-o'></i> 1 Hire</td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </tbody>
              </table>
            </div>
          </div>


        </div>
        <div class="clearfix"></div>
        
      </div>
      <br>
      <br>
    </div>
    <!-- divider section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>