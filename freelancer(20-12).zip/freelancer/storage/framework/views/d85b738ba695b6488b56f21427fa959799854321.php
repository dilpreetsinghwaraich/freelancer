<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
		<h1>All profetionls</h1>
		<span><a href="<?php echo e(url('/profetionls')); ?>/create">Add</a></span>
		<table class="table">
			<tr>
				<th>Name</th>
				<th>Description</th>
				
			</tr>

			<?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><a href="<?php echo e(url('/profetionls')); ?>/<?php echo e($cat->id); ?>/edit"><?php echo e($cat->name); ?></a></td>
					<td><?php echo e($cat->description); ?></td>
					<td>
					<form method="POST" action="<?php echo e(url('/profetionls')); ?>/<?php echo e($cat->id); ?>">

						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('DELETE')); ?>


							<button type="submit" class="btn btn-danger btn-sm">Delete</button>
						
						</form>	
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>