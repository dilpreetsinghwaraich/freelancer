<?php $__env->startSection('content'); ?>
<div class="login-section register-section">
<div class="login-page">
  <div class="form">
    <form class="login-form" method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo e(csrf_field()); ?>

	<h2>Sign Up</h2>
      <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="First Name"/>
      <input type="text" id="last_name" name="last_name" value="<?php echo e(old('last_name')); ?>" placeholder="Last Name" required />
	  <input type="email" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required />
	  <input type="password" id="password" name="password" placeholder="Password" required />
      <input id="password-confirm" type="password" name="password_confirmation" placeholder="Confirm Password" required>
	  
      <button type="submit">Get Started</button>
    
    </form>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>