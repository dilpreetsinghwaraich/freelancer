<?php $__env->startSection('content'); ?>
<div class="login-section register-section">
<div class="login-page">
  <div class="form">
	<form class="login-form" method="POST" action="<?php echo e(url('/categories')); ?>/<?php echo e($category->id); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

	<h2>Create Category</h2>
      <input type="text" id="name" name="name" value="<?php echo e($category->name); ?>" placeholder="Category Name"/>

      <select name="parent_id" id="parent_id">
      <option value="0">--Select Parent--</option>

      	<?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
         
      	<option 
             <?php if($cat->id == $category->parent_id): ?>
            selected="selected"
          <?php endif; ?>
          value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?>

          </option>
      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

	  <textarea name="description" id="description" cols="50" rows="5"><?php echo e($category->description); ?></textarea>
	  
      <button type="submit">Save</button>
    
    </form>
  </div>
  </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>