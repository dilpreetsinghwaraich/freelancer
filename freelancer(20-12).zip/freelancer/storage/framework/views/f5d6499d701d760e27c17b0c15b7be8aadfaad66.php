<?php $__env->startSection('content'); ?>
<div class="login-section">
<div class="login-page">
  <div class="form">
    <form class="login-form" method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo e(csrf_field()); ?>

	<h2>Login in and get to work</h2>
      <input  id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="Email"/>
      <input id="password" type="password" name="password" required placeholder="Password"/>

	  
              <label for="checkbox">
                  <input id="checkbox" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
              </label>
          
  
          
          <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
              Forgot Your Password?
          </a>
   
      <button>login</button>
      <p class="message">Do'nt have an account? <a href="<?php echo e(route('register')); ?>"> Sign up</a></p>
    </form>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>