<li><a href="<?php echo e(url('categories')); ?>">Manage Category</a></li>
<li><a href="<?php echo e(url('profetionls')); ?>">Manage Profetionls</a></li>