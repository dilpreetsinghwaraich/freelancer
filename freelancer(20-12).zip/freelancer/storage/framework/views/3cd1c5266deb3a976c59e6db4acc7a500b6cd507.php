<?php $__env->startSection('content'); ?>

<section class="profile_page_design">
  <div class="container">
    <div class="heading">
      <h3>My Profile</h3>
    </div>

    <div class="freelancer_info">
      <div class="col-md-8 col-sm-8 col-lg-8">
        <div class="profile_pic">
          <img src="<?php echo e(asset('images/profile-pic.png')); ?>" alt="profile-pic">
        </div>
        <div class="freelancer_name">
          <h2><?php echo e($user_data->name); ?> <?php echo e($user_data->last_name); ?></h2>
          <h4 data-toggle="modal" data-target="#edite">
          <?php if(!empty($profile_data)): ?>
            <?php echo e($profile_data->job_title); ?> 
          <?php endif; ?>
          <i class="fa fa-pencil-square-o edite" aria-hidden="true"></i>
          </h4>


          <!-- Trigger the modal with a button -->
          <!-- Modal -->
          <div class="Job-title-content">
            <?php echo $__env->make('user.job_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>

          <p> <i class="fa fa-map-marker" aria-hidden="true"></i> Usa, california - 10:12pm local time</p>
          <p><i class="fa fa-clock-o" aria-hidden="true"></i> $5.00 /hr</p>
        </div>

        <div class="skills">
          <?php echo $__env->make('user.professional', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>


        <div class="Overview">
          <?php echo $__env->make('user.overview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>


        <div class="porfolio">
          <?php echo $__env->make('user.portfolio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('user.edit_portfolio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>




        <div class="Education">
            <?php echo $__env->make('user.education', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
</div>
</form>
<div class="col-md-4 col-sm-4 col-lg-4 left-bar">
<a class="Setting" href="">Profile Setting</a>
<div class="Available">
<h3   data-toggle="modal" data-target="#Available">Available <a href="javascript:;"><i class="fa fa-pencil-square-o edite" aria-hidden="true"></i></a>
</h3>
<ul class="Availablelity">
<li><a href="">
<?php if(!empty($profile_data)): ?>
  <?php if(($profile_data->availability_type >=1) && empty($profile_data->not_available_text)): ?>
    Available
  <?php else: ?>
    Not Available
  <?php endif; ?>
<?php endif; ?>
</a></li>
<li><a href="">
<?php if(!empty($profile_data)): ?>
  <?php if($profile_data->availability_type ==1): ?>
    More than 30 hrs/week
  <?php elseif($profile_data->availability_type ==2): ?>
    Less than 30 hrs/week
  <?php elseif($profile_data->availability_type ==3): ?>
    As Needed - Open to Offers
  <?php endif; ?>
<?php endif; ?>
</a></li>
response time ?

<form method="POST" action="<?php echo e(url('/profileupdate')); ?>/<?php echo e($user_data->id); ?>">
          <?php echo e(csrf_field()); ?>

<div class="modal fade" id="Available" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Change Availability</h4>
        </div>
        <div class="modal-body">
 <div class="forms">
 <div class="col-lg-6 col-md-6 col-sm-6"> 
  <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
 
  <p><a href="">How do we use this info</a></p>
</div> 
 <div class="col-lg-6 col-md-6 col-sm-6"> 
		 <p><b>I am currently</b></p>
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#homes">Availabil</a></li>
    <li><a data-toggle="tab" href="#menu1">Not Availabil</a></li>
  </ul>

  <div class="tab-content">
    <div id="homes" class="tab-pane fade in active">
      <p> <label>
        <input name="availability_type" value="1" type="radio"
        <?php if(!empty($profile_data)): ?>
        <?php if($profile_data->availability_type == '1'): ?>
          checked
        <?php endif; ?>
        <?php endif; ?>
        > 
      More than 30 hrs/week </label></p>
	   <p> 
        <input name="availability_type" value="2" type="radio"
        <?php if(!empty($profile_data)): ?>
        <?php if($profile_data->availability_type == '2'): ?>
          checked
        <?php endif; ?>
        <?php endif; ?>
        >  
        Less than 30 hrs/week </p>
	    <p> 
        <input name="availability_type" value="3" type="radio"
        <?php if(!empty($profile_data)): ?>
        <?php if($profile_data->availability_type == '3'): ?>
          checked
        <?php endif; ?>
        <?php endif; ?>
        > 
        As Needed - Open to Offers</p>

 
    </div>
    <div id="menu1" class="tab-pane fade">
   <p><label>When do you expect to be ready for new work?</label> 
   <input name="not_available_text" value="<?php if(!empty($profile_data)): ?><?php echo e($profile_data->not_available_text); ?><?php endif; ?>" data-provide="datepicker"></p>
  </div>
		 
 </div>  
</div>  
 </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-default">Publish Project</button>
		   <a href="" class="btn-btn-default" data-dismiss="modal">Cancel</a>
        </div>
      </div>
    </div>
  </div>
</div>
</form>


</ul>


<div class="Languages">
<?php echo $__env->make('user.language', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>

<div class="phone-number">
<h3>Verifications <a href=""><i class="fa fa-pencil-square-o edite" aria-hidden="true"></i></a></h3>
<ul class="Availablelity">
<li><a href=""><b>Phone Number:</b><i class="fa fa-check" aria-hidden="true"></i>
 Verified</a> </li>
</ul>
</div>

</div>
</div>
</div>
</div>
</section>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.flprofile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>