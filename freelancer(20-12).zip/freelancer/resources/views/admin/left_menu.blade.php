<li><a href="{{ url('categories') }}">Manage Category</a></li>
<li><a href="{{ url('profetionls') }}">Manage Profetionls</a></li>